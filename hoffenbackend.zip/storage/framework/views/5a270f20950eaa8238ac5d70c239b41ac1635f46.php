<div>
    <p>Hello,</p>
    <p>I hope you are fit & fine. How are you?</p>
    <br>
    <p><b>Fullname :</b> <?php echo e($fullname); ?></p>
    <p><b>Email :</b> <?php echo e($email); ?></p>
    <p><b>Phone :</b> <?php echo e($phone); ?></p>
    <p><b>Massage :</b> <?php echo e($massage); ?></p>
    <br>
    <p>Thank you for your contact! I'll call you later</p>
    <p>Best & Regards</p>
    <p><b><?php echo e($fullname); ?></b></p>
    <p>Thanks</p>
</div>

<?php /**PATH C:\xampp\htdocs\hoffenbackend\resources\views\email_template\email.blade.php ENDPATH**/ ?>