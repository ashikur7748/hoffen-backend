<div>
    <p>Hello,</p>
    <p>I hope you are fit & fine. How are you?</p>
    <br>
    <p><b>Fullname :</b> {{ $fullname }}</p>
    <p><b>Email :</b> {{ $email }}</p>
    <p><b>Phone :</b> {{ $phone }}</p>
    <p><b>Massage :</b> {{ $massage }}</p>
    <br>
    <p>Thank you for your contact! I'll call you later</p>
    <p>Best & Regards</p>
    <p><b>{{ $fullname }}</b></p>
    <p>Thanks</p>
</div>

